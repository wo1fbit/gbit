# gbit

GtfoBins In the Terminal

To use run:
~~~
gbit [binary]
~~~

cheers;
wolf.