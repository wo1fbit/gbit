# gbit

GtfoBins In the Terminal

As of now, gbit is in maintenance-mode and being updated continuously.

To use run:
~~~
gbit [binary]
~~~