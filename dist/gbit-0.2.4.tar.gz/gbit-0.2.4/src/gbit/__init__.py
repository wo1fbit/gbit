__doc__= """GTFOBINS in the Terminal"""
__version__= "0.2.4"